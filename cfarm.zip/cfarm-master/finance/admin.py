from django.contrib import admin
from .models import Cost

admin.site.register(Cost)
