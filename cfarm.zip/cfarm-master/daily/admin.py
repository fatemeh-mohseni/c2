from django.contrib import admin
from .models import Daily_Informations
# Register your models here.
admin.site.register(Daily_Informations)
